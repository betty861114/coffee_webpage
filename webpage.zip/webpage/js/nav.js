//navbar固定在捲出後固定在畫面上方的動畫 
$(document).ready(function(){
   $(window).scroll(function(){
          if( $(document).scrollTop() > $('.navbar').height() ){
             $('nav').addClass('fixed');}
          if( $(document).scrollTop() ==0){
             $('nav').removeClass('fixed');}
             });  

}); //document end
      